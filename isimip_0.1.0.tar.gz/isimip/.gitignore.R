.Rproj.user
.Rhistory
.RData
.Ruserdata
docs
inst/doc
